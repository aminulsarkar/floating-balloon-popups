/**
 * Floating Balloon Popups
 * Interactive SVG balloon animation with GSAP
 *
 * @author Aminul Sarkar
 * @link https://aminulsarkar.com
 */

window.onload = function() {
(function(){
    
				const data = [
				{
					title: "There is so much to love!",
					items: [
					"Music and more music throughout the day",
					"Food trucks + Craft beer + Wine + Non-alcoholic brews",
					"A laser light show",
					"A spectacular hologram display"
					]
				},
				{
					title: "Bring the whole family!",
					items: [
					"Superhero meet and greets",
					"Bounce zone & family lawn + open-air & indoor acoustic stages"
					]
				},
				{
					title: "Free onsite Parking",
					items: ["Rain or Shine = all-weather event"]
				},
				{
					title: "Get your tickets now!",
					items: [ `<div class="no-bullet">Buy tickets online today! <a href="https://aminulsarkar.com/" target="_blank" class="ticket-btn-balloon">Buy Tickets</a></div>`]
				}
				];

				const stage = document.getElementById('benefit-balloons');

  // Create SVG
  const svgNS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(svgNS, 'svg');
  svg.setAttribute('id','balloon-svg');
  stage.appendChild(svg);

  function sizeSVG(){
  	svg.setAttribute('width', stage.clientWidth);
  	svg.setAttribute('height', stage.clientHeight);
  }
  sizeSVG();
  window.addEventListener('resize', sizeSVG);

  let uid = 0;
  function createBalloon(hue= Math.floor(Math.random()*360), scale=1){
  	const g = document.createElementNS(svgNS,'g');
  	g.setAttribute('class','balloon');
  	g.setAttribute('transform','translate(0,0) scale('+scale+')');
  	svg.appendChild(g);

  	const defs = document.createElementNS(svgNS,'defs');
  	const gradId = 'grad-'+(uid++);
  	const rg = document.createElementNS(svgNS,'radialGradient');
  	rg.setAttribute('id', gradId);
  	rg.setAttribute('cx','30%'); rg.setAttribute('cy','30%'); rg.setAttribute('r','70%');
  	const s1 = document.createElementNS(svgNS,'stop');
  	s1.setAttribute('offset','0%');  s1.setAttribute('stop-color', `hsl(${hue},90%,75%)`);
  	const s2 = document.createElementNS(svgNS,'stop');
  	s2.setAttribute('offset','100%'); s2.setAttribute('stop-color', `hsl(${hue},85%,45%)`);
  	rg.appendChild(s1); rg.appendChild(s2); defs.appendChild(rg);
  	g.appendChild(defs);

  	const string = document.createElementNS(svgNS,'path');
  	string.setAttribute('d','M0,42 C -8,70 -4,105 0,140');
  	string.setAttribute('fill','none');
  	string.setAttribute('stroke','rgba(255,255,255,.6)');
  	string.setAttribute('stroke-width','1.5');
  	string.setAttribute('stroke-linecap','round');
  	g.appendChild(string);

  	const body = document.createElementNS(svgNS,'ellipse');
  	body.setAttribute('cx','0'); body.setAttribute('cy','0');
  	body.setAttribute('rx','28'); body.setAttribute('ry','36');
  	body.setAttribute('fill', `url(#${gradId})`);
  	g.appendChild(body);

  	const knot = document.createElementNS(svgNS,'polygon');
  	knot.setAttribute('points','-6,34 6,34 0,44');
  	knot.setAttribute('fill', `hsl(${hue},85%,45%)`);
  	g.appendChild(knot);

  	const shine = document.createElementNS(svgNS,'ellipse');
  	shine.setAttribute('cx','-10'); shine.setAttribute('cy','-12');
  	shine.setAttribute('rx','8'); shine.setAttribute('ry','10');
  	shine.setAttribute('fill','rgba(255,255,255,.65)');
  	g.appendChild(shine);

  	return g;
  }

  function burstParticles(x,y, hue){
  	const count = 16;
  	for(let i=0;i<count;i++){
  		const c = document.createElementNS(svgNS,'circle');
  		c.setAttribute('cx', x); c.setAttribute('cy', y);
  		c.setAttribute('r', 4 + Math.random()*3);
  		c.setAttribute('fill', i%2 ? `hsl(${hue},95%,70%)` : `hsl(${hue},85%,50%)`);
  		svg.appendChild(c);

  		gsap.to(c, {
  			duration: gsap.utils.random(0.6, 1.2),
  			attr: {
  				cx: x + gsap.utils.random(-120,120),
  				cy: y + gsap.utils.random(-120,120)
  			},
  			opacity: 0,
  			ease: "power2.out",
  			onComplete: () => c.remove()
  		});
  	}
  }

  function showBenefitAt(xScreen, yScreen, group){
  	const stageRect = stage.getBoundingClientRect();
  	let x = xScreen - stageRect.left;
  	let y = yScreen - stageRect.top;

    // Adjust if near edges to stay fully visible
    x = Math.min(Math.max(160, x), stage.clientWidth - 160); // half max-width
    y = Math.min(Math.max(80, y), stage.clientHeight - 120); // avoid top/bottom cut

    const card = document.createElement('div');
    card.className = 'benefit-card';
    card.innerHTML = `
    <button class="benefit-close">×</button>
    <h3>${group.title}</h3>
    <ul>${group.items.map(it => `<li>${it}</li>`).join('')}</ul>
    `;
    stage.appendChild(card);

    gsap.set(card, { left: x, top: y, opacity: 0, scale: 0.85 });
    gsap.to(card, { opacity: 1, scale: 1, duration: 0.45, ease: "back.out(1.6)" });
    gsap.from(card.querySelectorAll('li'), { y: 8, opacity: 0, duration: 0.35, stagger: 0.06, ease: "power2.out", delay: 0.05 });

    // Close button handler
    card.querySelector(".benefit-close").addEventListener("click", () => {
    	gsap.to(card, { opacity: 0, scale: 0.8, duration: 0.3, onComplete: () => card.remove() });
    });

    // Auto remove after delay
    gsap.to(card, { opacity: 0, duration: 0.6, delay: 6.0, onComplete: ()=> card.remove() });
}


  // ---- Spawn balloons ----
  const W = () => stage.clientWidth;
  const H = () => stage.clientHeight;
  const verticalGap = 220;       // more vertical space
  const floatTop = 120;
  const baseDelay = 0.5;         // start after page load
  const delayStep = 5.0;         // stagger between balloons

  data.forEach((group, i) => {
  	const hue = Math.floor(Math.random()*360);
  	const balloon = createBalloon(hue, gsap.utils.random(1.0, 1.25));
  balloon.style.pointerEvents = "auto"; //  on iOS
  balloon.style.cursor = "pointer";

  const startX = gsap.utils.random(60, Math.max(120, W()-60));
  const startY = H() + i*verticalGap;

  gsap.set(balloon, { x: startX, y: startY });

  const drift = gsap.utils.random(-60, 60);

  // Balloon burst function (shared by animation + click)
  let popped = false;
  function burstNow() {
  	if (popped || !balloon.parentNode) return;
  	popped = true;

  	const r = balloon.getBoundingClientRect();
  	const cx = r.left + r.width/2;
  	const cy = r.top + r.height/2;

  	gsap.killTweensOf(balloon);
  	gsap.to(balloon, { scale: 1.2, duration: 0.12, ease: "power2.in" });
  	gsap.to(balloon, { 
  		scale: 0.2, opacity: 0, duration: 0.22, ease: "power3.in",
  		onComplete: () => balloon.remove()
  	});

  	burstParticles(cx, cy, hue);
  	showBenefitAt(cx, cy, group);
  }
  balloon.addEventListener("click", burstNow);
  balloon.addEventListener("touchstart", burstNow, { passive: true });


  // Auto float upwards & burst
  gsap.to(balloon, {
  	duration: gsap.utils.random(8.5, 10.5), 
  	x: startX + drift,
  	y: floatTop,
  	ease: "none",
  	delay: baseDelay + i*delayStep,
  	onStart: () => {
  		gsap.to(balloon, {
  			x: `+=${gsap.utils.random(-30,30)}`, 
  			duration: gsap.utils.random(1.5, 2.5),
  			ease: "sine.inOut",
  			repeat: -1,
  			yoyo: true
  		});
  	},
  	onComplete: burstNow
  });
});

})();
};